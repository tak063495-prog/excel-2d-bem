Attribute VB_Name = "BEM_Core"
Option Explicit

Public Models As Object
Public InterfacePairs As Collection
Public MeshFingerprint As String
Public LastImportFingerprint As String
Public Busy As Boolean
Public Const FIRST_ROW As Long = 6

Public Sub Fail(ByVal message As String)
    Err.Raise vbObjectError + 2048, "ElasticBEM", message
End Sub
Public Function WS(ByVal name As String) As Worksheet
    Set WS = ThisWorkbook.Worksheets(name)
End Function
Public Function TextAt(ByVal s As Worksheet, ByVal row As Long, ByVal col As Long) As String
    Dim value As Variant: value = s.Cells(row, col).Value2
    If IsError(value) Then Fail s.name & "!" & s.Cells(row, col).address(False, False) & ": �Z�����G���[�ł��B"
    TextAt = Trim$(CStr(value))
End Function
Public Function NumberAt(ByVal s As Worksheet, ByVal row As Long, ByVal col As Long) As Double
    Dim value As Variant, address As String
    value = s.Cells(row, col).Value2: address = s.name & "!" & s.Cells(row, col).address(False, False)
    If IsError(value) Then Fail address & ": �Z�����G���[�ł��B"
    If IsEmpty(value) Or VarType(value) = vbBoolean Then Fail address & ": ���l���K�v�ł��B"
    If Len(Trim$(CStr(value))) = 0 Or Not IsNumeric(value) Then Fail address & ": ���l���K�v�ł��B"
    NumberAt = CDbl(value)
    If Abs(NumberAt) > 1E+100 Then Fail address & ": ���l�̐�Βl���傫�����܂��B"
End Function
Public Function ZeroIfBlank(ByVal s As Worksheet, ByVal row As Long, ByVal col As Long) As Double
    If TextAt(s, row, col) <> "" Then ZeroIfBlank = NumberAt(s, row, col)
End Function
Public Function LastRow(ByVal s As Worksheet, ByVal ncols As Long) As Long
    Dim col As Long, row As Long: LastRow = FIRST_ROW - 1
    For col = 1 To ncols
        row = s.Cells(s.rows.count, col).End(xlUp).row
        If row > LastRow Then LastRow = row
    Next col
    If LastRow > 10005 Then Fail s.name & ": ���͍s��10000�s�܂łł��B"
End Function
Public Function ActiveRow(ByVal s As Worksheet, ByVal row As Long, ByVal ncols As Long) As Boolean
    Dim col As Long, used As Boolean
    For col = 1 To ncols
        If TextAt(s, row, col) <> "" Then used = True
    Next col
    If used And TextAt(s, row, 1) = "" Then Fail s.name & " �s" & row & ": �̈�ID�܂���ID���󗓂ł��B"
    ActiveRow = used
End Function
Public Function ValidId(ByVal value As String) As Boolean
    Dim re As Object: Set re = CreateObject("VBScript.RegExp")
    re.Pattern = "^[A-Za-z0-9_-]+$": ValidId = re.Test(value)
End Function
Public Function CurrentDimension() As Long
    Select Case TextAt(WS("����"), 5, 2)
    Case "2D": CurrentDimension = 2
    Case "3D": CurrentDimension = 3
    Case Else: Fail "����!B5: 2D�܂���3D��I�����Ă��������B"
    End Select
End Function
Public Function CurrentOrder() As Long
    Dim v As Double: v = NumberAt(WS("����"), 7, 2)
    If v <> 0 And v <> 2 Then Fail "����!B7: �v�f������0�܂���2�ł��B"
    CurrentOrder = CLng(v)
End Function
Public Function MeshSize() As Double
    MeshSize = NumberAt(WS("����"), 8, 2)
    If MeshSize <= 0 Then Fail "����!B8: h�͐��̐��ł��B"
End Function
Public Function Ceiling(ByVal value As Double) As Long
    If value > 100000 Or value < 0 Then Fail "������������𒴂��Ă��܂��Bh��傫�����Ă��������B"
    Ceiling = CLng(-Int(-value))
    If Ceiling < 1 Then Ceiling = 1
End Function
Public Function DivisionAt(ByVal row As Long, ByVal col As Long, ByVal fallback As Long, Optional ByVal minimum As Long = 1) As Long
    Dim v As Double: v = ZeroIfBlank(WS("�̈�"), row, col)
    If v < 0 Or v <> Fix(v) Or v > 100000 Then Fail "�̈� �s" & row & ": ��������0�܂��͐��̐����ł��B"
    If v = 0 Then v = MaxLong(fallback, minimum)
    If v < minimum Then Fail "�̈� �s" & row & ": ��������" & minimum & "�ȏ�ł��B"
    DivisionAt = CLng(v)
End Function
Public Function DivisionFromSize(ByVal row As Long, ByVal col As Long, ByVal ratio As Double, Optional ByVal minimum As Long = 1) As Long
    If ZeroIfBlank(WS("�̈�"), row, col) = 0 Then
        DivisionFromSize = DivisionAt(row, col, MaxLong(minimum, Ceiling(ratio)), minimum)
    Else
        DivisionFromSize = DivisionAt(row, col, minimum, minimum)
    End If
End Function

Public Function InputFingerprint() As String
    Dim name As Variant, s As Worksheet, data As Variant, nr As Long, nc As Long, i As Long, j As Long
    Dim parts As Collection: Set parts = New Collection
    data = WS("����").Range("B5:B13").Value2
    For i = 1 To UBound(data, 1)
        If IsError(data(i, 1)) Then Fail "����V�[�g�ɃZ���G���[������܂��B"
        parts.Add JQuote(CStr(data(i, 1)))
    Next i
    data = WS("����").Range("B34:B61").Value2
    For i = 1 To UBound(data, 1)
        If IsError(data(i, 1)) Then Fail "��͐ݒ�ɃZ���G���[������܂��B"
        parts.Add JQuote(CStr(data(i, 1)))
    Next i
    For Each name In Array("�ޗ�", "�̈�", "�֊s2D", "���E����", "�ڍ�", "�]���_")
        Set s = WS(CStr(name))
        Select Case CStr(name)
        Case "�̈�": nc = 13
        Case "���E����": nc = 8
        Case "�]���_": nc = 5
        Case Else: nc = 4
        End Select
        nr = LastRow(s, nc): parts.Add CStr(name)
        If nr >= FIRST_ROW Then
            data = s.Range(s.Cells(FIRST_ROW, 1), s.Cells(nr, nc)).Value2
            For i = 1 To UBound(data, 1)
                For j = 1 To nc
                    If IsError(data(i, j)) Then Fail CStr(name) & ": �Z���G���[������܂��B"
                    parts.Add JQuote(CStr(data(i, j)))
                Next j
                parts.Add ";"
            Next i
        End If
    Next name
    InputFingerprint = JoinCollection(parts, ",")
End Function

Public Sub BuildModels()
    Dim oldEvents As Boolean, mats As Object, newModels As Object, s As Worksheet, row As Long, id As String
    Dim r As CBemRegion, v As Variant, h As Double, d As Long, order As Long, state As String
    Dim estimate As Double, count As Double, cap As Double, nx As Long, ny As Long, nz As Long
    Dim corners As Variant, i As Long, span As Variant, lower As Variant, upper As Variant
    Dim fingerprint As String, description As String, errnum As Long
    On Error GoTo Failed
    d = CurrentDimension(): order = CurrentOrder(): h = MeshSize()
    state = TextAt(WS("����"), 6, 2)
    If d = 2 And state <> "plane_strain" And state <> "plane_stress" Then Fail "2D��͏�Ԃ�I�����Ă��������B"
    cap = NumberAt(WS("����"), 9, 2)
    If cap <> Fix(cap) Or cap < 4 Or cap > 100000 Then Fail "�ő�v�f����4�`100000�̐����ł��B"
    fingerprint = InputFingerprint()
    Set mats = CreateObject("Scripting.Dictionary"): Set newModels = CreateObject("Scripting.Dictionary")
    Set s = WS("�ޗ�")
    For row = FIRST_ROW To LastRow(s, 4)
        If ActiveRow(s, row, 4) Then
            id = TextAt(s, row, 1)
            If Not ValidId(id) Or mats.Exists(id) Then Fail "�ޗ� �s" & row & ": ID���s���܂��͏d�����Ă��܂��B"
            v = Array(NumberAt(s, row, 2), NumberAt(s, row, 3))
            If v(0) <= 0 Or v(1) <= -1 Or v(1) >= 0.5 Then Fail "�ޗ� �s" & row & ": E>0�A-1<��<0.5���K�v�ł��B"
            mats.Add id, v
        End If
    Next row
    Set s = WS("�̈�")
    For row = FIRST_ROW To LastRow(s, 13)
        If ActiveRow(s, row, 13) Then
            Set r = New CBemRegion: r.RegionName = TextAt(s, row, 1)
            If Not ValidId(r.RegionName) Or newModels.Exists(r.RegionName) Then Fail "�̈� �s" & row & ": ID���s���܂��͏d�����Ă��܂��B"
            r.dimension = d: r.ElementOrder = order: r.ShapeName = UCase$(TextAt(s, row, 2)): r.MaterialId = TextAt(s, row, 3)
            If Not mats.Exists(r.MaterialId) Then Fail "�̈� �s" & row & ": �ޗ�ID��������܂���B"
            v = mats(r.MaterialId): r.Young = v(0): r.Poisson = v(1)
            If r.ShapeName = "POLYGON" Then r.Origin = Array(0#, 0#, 0#) Else r.Origin = Array(NumberAt(s, row, 4), NumberAt(s, row, 5), 0#)
            If d = 3 Then r.Origin = Array(r.Origin(0), r.Origin(1), NumberAt(s, row, 6))
            r.Sizes = Array(0#, 0#, 0#): nx = 0: ny = 0: nz = 0
            Select Case r.ShapeName
            Case "RECT", "BOX"
                If (d = 2 And r.ShapeName <> "RECT") Or (d = 3 And r.ShapeName <> "BOX") Then Fail "�̈� �s" & row & ": ��͎����ɑΉ�����`���I�����Ă��������B"
                span = Array(NumberAt(s, row, 7), NumberAt(s, row, 8), 0#)
                If d = 3 Then span(2) = NumberAt(s, row, 9)
                For i = 0 To d - 1
                    If span(i) <= 0 Then Fail "�̈� �s" & row & ": ���@�͐��̐��ł��B"
                Next i
                r.Sizes = span: r.ModelScale = MaxDouble(span(0), MaxDouble(span(1), span(2)))
                nx = DivisionFromSize(row, 11, span(0) / h): ny = DivisionFromSize(row, 12, span(1) / h)
                If d = 3 Then nz = DivisionFromSize(row, 13, span(2) / h)
                If d = 2 Then count = 2# * (nx + ny) Else count = 4# * (CDbl(nx) * ny + CDbl(ny) * nz + CDbl(nz) * nx)
            Case "CIRCLE", "SPHERE"
                If (d = 2 And r.ShapeName <> "CIRCLE") Or (d = 3 And r.ShapeName <> "SPHERE") Then Fail "�̈� �s" & row & ": ��͎����ɑΉ�����`���I�����Ă��������B"
                r.Radius = NumberAt(s, row, 10)
                If r.Radius <= 0 Then Fail "�̈� �s" & row & ": ���a�͐��̐��ł��B"
                r.ModelScale = 2 * r.Radius: nx = DivisionFromSize(row, 11, 2 * PI * r.Radius / h, 8)
                If d = 2 Then
                    count = nx
                Else
                    ny = DivisionFromSize(row, 12, PI * r.Radius / h, 4): count = 2# * nx * (ny - 1)
                End If
            Case "POLYGON"
                If d <> 2 Then Fail "POLYGON��2D��p�ł��B"
                corners = ReadPolygon(r): lower = corners(0): upper = corners(0)
                For i = 0 To UBound(corners)
                    lower = Array(MinDouble(lower(0), corners(i)(0)), MinDouble(lower(1), corners(i)(1)), 0#)
                    upper = Array(MaxDouble(upper(0), corners(i)(0)), MaxDouble(upper(1), corners(i)(1)), 0#)
                Next i
                r.Origin = lower: span = Sub3(upper, lower): r.ModelScale = MaxDouble(span(0), span(1))
                nx = DivisionAt(row, 11, 0): If ZeroIfBlank(s, row, 11) = 0 Then nx = 0
                count = 0
                For i = 0 To UBound(corners)
                    If nx > 0 Then count = count + nx Else count = count + Ceiling(Norm3(Sub3(corners(i), corners((i + 1) Mod (UBound(corners) + 1)))) / h)
                Next i
            Case Else: Fail "�̈� �s" & row & ": �`���I�����Ă��������B"
            End Select
            If r.ModelScale < 0.0000000001 Or r.ModelScale > 1000000000000# Then Fail r.RegionName & ": ���f�����@��1E-10�`1E12 m�ł��B"
            For i = 0 To d - 1
                If Abs(r.Origin(i)) > r.ModelScale * 100000000 Then Fail r.RegionName & ": ���_�����f���̋߂��Ɉڂ��Ă��������i�ۂߌ덷�΍�j�B"
            Next i
            estimate = estimate + count
            If estimate > cap Then Fail "�v�f���̌��ς��� " & Format$(estimate, "0") & " ����� " & cap & " �𒴂��܂��B�����������炵�Ă��������B"
            r.Divisions = Array(nx, ny, nz): newModels.Add r.RegionName, r
        End If
    Next row
    If newModels.count = 0 Then Fail "���Ȃ��Ƃ�1�̈����͂��Ă��������B"
    For Each v In newModels.keys
        Set r = newModels(v): GenerateGeometry r
    Next v
    'Only commit models after geometry generation; failed later checks invalidate the in-memory model.
    Set Models = newModels
    ReadBoundaryRules
    MatchInterfaces
    ReadEvaluationPoints
    CheckRigidModes
    MeshFingerprint = fingerprint
    Exit Sub
Failed:
    errnum = Err.number: description = Err.description
    Set Models = Nothing: MeshFingerprint = ""
    Err.Raise errnum, "ElasticBEM", description
End Sub

Public Function MaxDouble(ByVal a As Double, ByVal b As Double) As Double
    If a > b Then MaxDouble = a Else MaxDouble = b
End Function
Public Function MinDouble(ByVal a As Double, ByVal b As Double) As Double
    If a < b Then MinDouble = a Else MinDouble = b
End Function

Public Function PolygonArea(ByVal points As Variant) As Double
    Dim i As Long, a As Variant, b As Variant, base As Variant, total As Double, compensation As Double
    base = points(0)
    For i = 0 To UBound(points)
        a = Sub3(points(i), base): b = Sub3(points((i + 1) Mod (UBound(points) + 1)), base)
        CompensatedAdd total, compensation, a(0) * b(1) - a(1) * b(0)
    Next i
    PolygonArea = total / 2
End Function
Public Function ReadPolygon(ByVal r As CBemRegion) As Variant
    Dim s As Worksheet, items As Object, row As Long, id As String, seq As Double, i As Long, j As Long
    Dim p() As Variant, a As Variant, b As Variant, n As Long, ModelScale As Double, tol As Double
    Set s = WS("�֊s2D"): Set items = CreateObject("Scripting.Dictionary")
    For row = FIRST_ROW To LastRow(s, 4)
        If ActiveRow(s, row, 4) Then
            id = TextAt(s, row, 1)
            If id = r.RegionName Then
                seq = NumberAt(s, row, 2)
                If seq < 1 Or seq <> Fix(seq) Or seq > 10000 Then Fail "�֊s2D: ���Ԃ�1�`10000�̐����ł��B"
                If items.Exists(CStr(seq)) Then Fail "�֊s2D: ���Ԃ��d�����Ă��܂��B"
                items.Add CStr(seq), Array(NumberAt(s, row, 3), NumberAt(s, row, 4), 0#)
            End If
        End If
    Next row
    n = items.count
    If n < 3 Then Fail r.RegionName & ": ���p�`��3���_�ȏ�K�v�ł��B"
    ReDim p(0 To n - 1)
    For i = 1 To n
        If Not items.Exists(CStr(i)) Then Fail r.RegionName & ": ���_�̏��Ԃ�1����A�Ԃœ��͂��Ă��������B"
        p(i - 1) = items(CStr(i)): ModelScale = MaxDouble(ModelScale, Norm3(Sub3(p(i - 1), items("1"))))
    Next i
    tol = MaxDouble(ModelScale * 0.00000000001, 1E-20)
    If Abs(PolygonArea(p)) <= tol * ModelScale Then Fail r.RegionName & ": ���p�`�̖ʐς�0�ł��B"
    For i = 0 To n - 1
        a = p(i): b = p((i + 1) Mod n)
        If Norm3(Sub3(b, a)) <= tol Then Fail r.RegionName & ": �d�����_������܂��B�擪�𖖔��ɍē��͂��Ȃ��ł��������B"
        If Abs(Orient2(a, b, p((i + 2) Mod n))) <= tol * Norm3(Sub3(b, a)) Then
            If Dot3(Sub3(b, a), Sub3(p((i + 2) Mod n), b)) < 0 Then Fail r.RegionName & ": �אڂ���ӂ��܂�Ԃ��ďd�Ȃ��Ă��܂��B"
        End If
        For j = i + 1 To n - 1
            If j <> i + 1 And Not (i = 0 And j = n - 1) Then
                If SegmentsIntersect(a, b, p(j), p((j + 1) Mod n), tol) Then Fail r.RegionName & ": ���p�`�����Ȍ����܂��͐ڐG���Ă��܂��B"
            End If
        Next j
    Next i
    ReadPolygon = p
End Function
Private Function Orient2(ByVal a As Variant, ByVal b As Variant, ByVal c As Variant) As Double
    Orient2 = (b(0) - a(0)) * (c(1) - a(1)) - (b(1) - a(1)) * (c(0) - a(0))
End Function
Private Function OnSegment(ByVal a As Variant, ByVal b As Variant, ByVal p As Variant, ByVal tol As Double) As Boolean
    OnSegment = Abs(Orient2(a, b, p)) <= tol * Norm3(Sub3(b, a)) And p(0) >= MinDouble(a(0), b(0)) - tol And p(0) <= MaxDouble(a(0), b(0)) + tol And p(1) >= MinDouble(a(1), b(1)) - tol And p(1) <= MaxDouble(a(1), b(1)) + tol
End Function
Private Function SegmentsIntersect(ByVal a As Variant, ByVal b As Variant, ByVal c As Variant, ByVal d As Variant, ByVal tol As Double) As Boolean
    Dim o1 As Double, o2 As Double, o3 As Double, o4 As Double
    o1 = Orient2(a, b, c): o2 = Orient2(a, b, d): o3 = Orient2(c, d, a): o4 = Orient2(c, d, b)
    SegmentsIntersect = ((o1 > 0 And o2 < 0) Or (o1 < 0 And o2 > 0)) And ((o3 > 0 And o4 < 0) Or (o3 < 0 And o4 > 0))
    If OnSegment(a, b, c, tol) Or OnSegment(a, b, d, tol) Or OnSegment(c, d, a, tol) Or OnSegment(c, d, b, tol) Then SegmentsIntersect = True
End Function

Private Sub ReadBoundaryRules()
    Dim s As Worksheet, row As Long, r As CBemRegion, id As String, boundary As String, kinds As Variant, values As Variant, j As Long
    Dim key As Variant, col As Long, kind As String
    Set s = WS("���E����")
    For row = FIRST_ROW To LastRow(s, 8)
        If ActiveRow(s, row, 8) Then
            id = TextAt(s, row, 1): If Not Models.Exists(id) Then Fail "���E���� �s" & row & ": �̈�ID��������܂���B"
            Set r = Models(id): boundary = UCase$(TextAt(s, row, 2))
            If boundary <> "ALL" And Not r.groups.Exists(boundary) Then Fail id & ": ���E�� " & boundary & " ������܂���B"
            If r.Rules.Exists(boundary) Then Fail id & "/" & boundary & ": ���E�������d�����Ă��܂��B"
            kinds = Array("t", "t", "t"): values = Array(0#, 0#, 0#)
            For j = 0 To r.dimension - 1
                col = 3 + 2 * j: kind = LCase$(TextAt(s, row, col))
                If kind <> "u" And kind <> "t" Then Fail "���E���� �s" & row & ": ��ʂ�u�܂���t�ł��B"
                kinds(j) = kind: values(j) = NumberAt(s, row, col + 1)
            Next j
            r.Rules.Add boundary, Array(kinds, values)
        End If
    Next row
End Sub

Private Function ElementKey(ByVal r As CBemRegion, ByVal e As Long, ByVal tol As Double) As String
    Dim ids As Variant, p As Variant, keys() As String, i As Long, j As Long, temp As String
    ids = r.elements(e + 1): ReDim keys(0 To UBound(ids))
    For i = 0 To UBound(ids)
        p = r.Vertices(ids(i) + 1)
        keys(i) = Format$(p(0) / tol, "0") & "," & Format$(p(1) / tol, "0") & "," & Format$(p(2) / tol, "0")
    Next i
    For i = 1 To UBound(keys)
        temp = keys(i): j = i - 1
        Do While j >= 0
            If StrComp(keys(j), temp, vbBinaryCompare) <= 0 Then Exit Do
            keys(j + 1) = keys(j): j = j - 1
        Loop
        keys(j + 1) = temp
    Next i
    ElementKey = Join(keys, ";")
End Function
Private Sub MatchInterfaces()
    Dim s As Worksheet, row As Long, a As CBemRegion, b As CBemRegion, ba As String, bb As String
    Dim key As String, lookup As Object, ea As Collection, eb As Collection, id As Variant, e As Variant, f As Long
    Dim na As Variant, nb As Variant, jac As Double, tol As Double, idsA As Variant, idsB As Variant, pairs As Collection
    Dim i As Long, j As Long, pa As Variant, pb As Variant, good As Boolean
    Set InterfacePairs = New Collection: Set s = WS("�ڍ�")
    For row = FIRST_ROW To LastRow(s, 4)
        If ActiveRow(s, row, 4) Then
            If Not Models.Exists(TextAt(s, row, 1)) Or Not Models.Exists(TextAt(s, row, 3)) Then Fail "�ڍ� �s" & row & ": �̈�ID��������܂���B"
            Set a = Models(TextAt(s, row, 1)): Set b = Models(TextAt(s, row, 3))
            If a.RegionName = b.RegionName Then Fail "�ڍ��͈قȂ�2�̈���w�肵�Ă��������B"
            ba = UCase$(TextAt(s, row, 2)): bb = UCase$(TextAt(s, row, 4))
            If Not a.groups.Exists(ba) Or Not b.groups.Exists(bb) Then Fail "�ڍ� �s" & row & ": ���E����������܂���B"
            If a.InterfaceGroups.Exists(ba) Or b.InterfaceGroups.Exists(bb) Then Fail "�ڍ����E���d�����Ă��܂��B"
            If a.Rules.Exists(ba) Or b.Rules.Exists(bb) Then Fail "�ڍ��ʂ̌ʋ��E�������폜���Ă��������BALL�͊O�����E�ɂ����K�p����܂��B"
            Set ea = a.groups(ba): Set eb = b.groups(bb)
            If ea.count <> eb.count Then Fail "�ڍ��ʂ̗v�f�����قȂ�܂��B�������𑵂��Ă��������B"
            tol = MaxDouble(a.ModelScale, b.ModelScale) * 0.00000000001
            Set lookup = CreateObject("Scripting.Dictionary"): Set pairs = New Collection
            For Each e In eb
                key = ElementKey(b, CLng(e), tol)
                If lookup.Exists(key) Then Fail "�ڍ��ʂɏd���v�f������܂��B"
                lookup.Add key, CLng(e)
            Next e
            For Each e In ea
                key = ElementKey(a, CLng(e), tol)
                If Not lookup.Exists(key) Then Fail "�ڍ��ʂ̐ߓ_�E��������v���܂���B"
                f = lookup(key): lookup.Remove key
                'Compare actual coordinates after hashing, including quadratic midside nodes.
                idsA = a.elements(CLng(e) + 1): idsB = b.elements(f + 1)
                For i = 0 To UBound(idsA)
                    pa = a.Vertices(idsA(i) + 1): good = False
                    For j = 0 To UBound(idsB)
                        pb = b.Vertices(idsB(j) + 1)
                        If Norm3(Sub3(pa, pb)) <= tol * 2 Then good = True
                    Next j
                    If Not good Then Fail "�ڍ��ʂ̊􉽐ߓ_����v���܂���B"
                Next i
                na = a.Differential(CLng(e), IIf(a.dimension = 2, 0, 1 / 3), 1 / 3, jac)
                nb = b.Differential(f, IIf(b.dimension = 2, 0, 1 / 3), 1 / 3, jac)
                If Norm3(Add3(na, nb)) > 0.00000001 Then Fail "�ڍ��ʂ̖@�������Ό����ł͂���܂���B"
                pairs.Add f
            Next e
            a.InterfaceGroups.Add ba, b.RegionName: b.InterfaceGroups.Add bb, a.RegionName
            InterfacePairs.Add Array(a.RegionName, ba, b.RegionName, bb, pairs)
        End If
    Next row
    For Each id In Models.keys
        Set a = Models(id)
        For Each e In a.groups.keys
            If Not a.InterfaceGroups.Exists(e) Then pa = a.RuleFor(CStr(e))
        Next e
    Next id
End Sub

Private Sub ReadEvaluationPoints()
    Dim s As Worksheet, row As Long, r As CBemRegion, id As String, pointId As String, p As Variant, allIds As Object
    Set s = WS("�]���_"): Set allIds = CreateObject("Scripting.Dictionary")
    For row = FIRST_ROW To LastRow(s, 5)
        If ActiveRow(s, row, 5) Then
            id = TextAt(s, row, 1): If Not Models.Exists(id) Then Fail "�]���_ �s" & row & ": �̈�ID��������܂���B"
            Set r = Models(id): pointId = TextAt(s, row, 2)
            If Not ValidId(pointId) Or allIds.Exists(id & "/" & pointId) Then Fail "�]���_: �_ID���s���܂��͏d�����Ă��܂��B"
            allIds.Add id & "/" & pointId, True
            p = Array(NumberAt(s, row, 3), NumberAt(s, row, 4), 0#)
            If r.dimension = 3 Then p(2) = NumberAt(s, row, 5)
            If r.dimension = 2 And ZeroIfBlank(s, row, 5) <> 0 Then Fail "2D�̕]���_��Z�͋󗓂܂���0�ł��B"
            If Not StrictlyInside(r, p) Then Fail id & "/" & pointId & ": �_���̈�����ɂ���܂���i���E����s�j�B"
            r.points.Add p: r.PointIds.Add pointId
        End If
    Next row
End Sub
Public Function StrictlyInside(ByVal r As CBemRegion, ByVal p As Variant) As Boolean
    Dim v As Variant, i As Long, j As Long, q As Variant, a As Variant, b As Variant, tol As Double, inside As Boolean
    Dim proj As Double, dist As Double, denom As Double
    tol = r.ModelScale * 0.000000001: q = Sub3(p, r.Origin)
    Select Case r.ShapeName
    Case "RECT", "BOX"
        StrictlyInside = True
        For i = 0 To r.dimension - 1
            If q(i) <= tol Or q(i) >= r.Sizes(i) - tol Then StrictlyInside = False
        Next i
    Case "CIRCLE", "SPHERE"
        StrictlyInside = InsideRoundMesh(r, p)
    Case "POLYGON"
        v = ReadPolygon(r): j = UBound(v)
        For i = 0 To UBound(v)
            a = v(j): b = v(i)
            If OnSegment(a, b, p, tol) Then Exit Function
            If (a(1) > p(1)) <> (b(1) > p(1)) Then
                If p(0) < (b(0) - a(0)) * (p(1) - a(1)) / (b(1) - a(1)) + a(0) Then inside = Not inside
            End If
            j = i
        Next i
        StrictlyInside = inside
    End Select
End Function

Private Sub CheckRigidModes()
    Dim done As Object, members As Object, queue As Collection, name As Variant, item As Variant, boundary As Variant
    Dim r As CBemRegion, p As Variant, lower As Variant, upper As Variant, center As Variant, ModelScale As Double
    Dim vectors As Collection, e As Variant, j As Long, k As Long, rule As Variant, row As Variant, rank As Long, modes As Long
    Set done = CreateObject("Scripting.Dictionary")
    For Each name In Models.keys
        If Not done.Exists(name) Then
            Set members = CreateObject("Scripting.Dictionary"): Set queue = New Collection
            queue.Add CStr(name): members.Add CStr(name), True
            Do While queue.count > 0
                item = queue(1): queue.Remove 1: Set r = Models(item)
                For Each boundary In r.InterfaceGroups.keys
                    If Not members.Exists(r.InterfaceGroups(boundary)) Then members.Add r.InterfaceGroups(boundary), True: queue.Add r.InterfaceGroups(boundary)
                Next boundary
            Loop
            Set r = Models(name): lower = r.Vertices(1): upper = lower
            For Each item In members.keys
                done.Add item, True: Set r = Models(item)
                For Each p In r.Vertices
                    For j = 0 To r.dimension - 1
                        lower(j) = MinDouble(lower(j), p(j)): upper(j) = MaxDouble(upper(j), p(j))
                    Next j
                Next p
            Next item
            center = Mul3(Add3(lower, upper), 0.5): ModelScale = MaxDouble(upper(0) - lower(0), MaxDouble(upper(1) - lower(1), upper(2) - lower(2)))
            Set vectors = New Collection: modes = IIf(r.dimension = 2, 3, 6)
            For Each item In members.keys
                Set r = Models(item)
                For Each boundary In r.groups.keys
                    If Not r.InterfaceGroups.Exists(boundary) Then
                        rule = r.RuleFor(CStr(boundary))
                        For Each e In r.groups(boundary)
                            For k = 0 To r.FieldCount - 1
                                p = Mul3(Sub3(r.CollocationPoint(CLng(e), k), center), 1 / ModelScale)
                                For j = 0 To r.dimension - 1
                                    If rule(0)(j) = "u" Then
                                        If r.dimension = 2 Then
                                            If j = 0 Then row = Array(1#, 0#, -p(1)) Else row = Array(0#, 1#, p(0))
                                        Else
                                            Select Case j
                                            Case 0: row = Array(1#, 0#, 0#, 0#, p(2), -p(1))
                                            Case 1: row = Array(0#, 1#, 0#, -p(2), 0#, p(0))
                                            Case 2: row = Array(0#, 0#, 1#, p(1), -p(0), 0#)
                                            End Select
                                        End If
                                        AddIndependent vectors, row
                                    End If
                                Next j
                            Next k
                        Next e
                    End If
                Next boundary
            Next item
            If vectors.count < modes Then Fail CStr(name) & "���܂ޘA���̈�: ���̉^���̍S�����s�����Ă��܂��i�Ɨ��S�� " & vectors.count & "/" & modes & "�j�B"
        End If
    Next name
End Sub
Private Sub AddIndependent(ByVal basis As Collection, ByVal row As Variant)
    Dim v As Variant, i As Long, pass As Long, dot As Double, length As Double
    For pass = 1 To 2
        For Each v In basis
            dot = 0
            For i = 0 To UBound(row): dot = dot + row(i) * v(i): Next i
            For i = 0 To UBound(row): row(i) = row(i) - dot * v(i): Next i
        Next v
    Next pass
    For i = 0 To UBound(row): length = length + row(i) * row(i): Next i
    length = Sqr(length)
    If length > 0.00000001 Then
        For i = 0 To UBound(row): row(i) = row(i) / length: Next i
        basis.Add row
    End If
End Sub

